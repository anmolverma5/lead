<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Lead;
use App\Models\Source;
use App\Models\User;
use App\Models\Note;

use App\Http\Requests\LeadRequest;
use App\Http\Requests\SearchLeadRequest;
use App\Http\Requests\AssignLeadRequest;

use Validator;

class LeadsController extends Controller
{
    
    
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {

        if (!isset($_GET['status'])) {

            $data = Lead::where(['user_id'=>auth()->user()->id])->with('source')->with('feedback')->get()->toArray();
       } else{
            $data = Lead::where(['user_id'=>auth()->user()->id,'status'=>$_GET['status']])->with('source')->with('feedback')->get()->toArray();
       }

         //$data = Lead::with('source')->with('feedback')->get()->toArray();
         $sources = Source::where(['user_id'=>auth()->user()->id])->select('id','source_name')->get()->toArray();
         $source_ids ="";
         return view('leads.list')->with(['data'=>$data,'sources'=>$sources,'source_ids'=>$source_ids]);
    }

  
    public function create()
    {
        $sources = Source::where(['user_id'=>auth()->user()->id])->select('id','source_name')->get()->toArray();
        return view('leads.add')->with(['sources'=>$sources]);
    }


    public function store(Request $request)
    {
        
        $data = array(
            'user_id'=>auth()->user()->id,
            'source_id'=>$request->source_id,
            /*'company_name'=>$request->company_name,*/
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            /*'job_title'=>$request->job_title,*/
            'email'=>$request->email,
            'phone_no'=>$request->phone_no,
            /*'web_address'=>$request->web_address,
            'employee_size'=>$request->employee_size,
            'revenue_size'=>$request->revenue_size,
            'industry'=>$request->industry,
            'physical_address'=>$request->physical_address,
            'city'=>$request->city,
            'state'=>$request->state,
            'zip_code'=>$request->zip_code,
            'country'=>$request->country,
            'linkedin_address'=>$request->linkedin_address,
            'lead_name'=>$request->job_title,*/
              
        );
        
        lead::create($data);
        
        return redirect('leads')->with('success', 'Lead Added Successfully.');
    }

  
    public function show($id)
    {
        $data = Lead::where(['id'=>$id])->with('source')->with('user')->first()->toArray();
        //dd($data);
        return view('leads.show')->with(['data'=>$data]);
    }


    public function edit($id)
    {
        
        $sources = Source::where(['user_id'=>auth()->user()->id])->select('id','source_name')->get()->toArray();
        $data = Lead::where(['id'=>$id])->first();
        return view('leads.edit')->with(['data'=>$data,'sources'=>$sources]);
    }


    public function update(Request $request, $id)
    {
        $validator = Validator::make(
            $request->all(), [
                'source_id' => 'required',
                /*'company_name' => 'required|min:3|max:20',*/
                'first_name' => 'required|min:3|max:20',
                'last_name' => 'required|min:3|max:20',
                /*'job_title' => 'required|min:3|max:20',*/
                'email' => 'required|email|unique:leads,email,'.$id,
                'phone_no' => 'required|min:10|numeric|unique:leads,phone_no,'.$id,
                /*'web_address' => 'required|min:3',
                'employee_size' => 'required|numeric',
                'revenue_size' => 'required|numeric',
                'industry' => 'required|min:3|max:20',
                'physical_address' => 'required|min:3|max:50',
                'city' => 'required|min:3|max:20',
                'state' => 'required|min:3|max:20',
                'zip_code' => 'required|min:3|max:20',
                'country' => 'required|min:3|max:20',
                'linkedin_address' => 'required|min:3',*/
            ],
            $messages = [
                'required' => 'The :attribute field is required.',
            ]
        );
        
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        
        $input = $request->all(); 

        $data = Lead::find($id);
        
        $data->source_id = $input['source_id'];
        /*$data->company_name = $input['company_name'];*/
        $data->first_name = $input['first_name'];
        $data->last_name = $input['last_name'];
        /*$data->job_title = $input['job_title'];*/
        $data->email = $input['email'];
        $data->phone_no = $input['phone_no'];
        /*$data->web_address = $input['web_address'];
        $data->employee_size = $input['employee_size'];
        $data->revenue_size = $input['revenue_size'];
        $data->industry = $input['industry'];
        $data->physical_address = $input['physical_address'];
        $data->city = $input['city'];
        $data->state = $input['state'];
        $data->zip_code = $input['zip_code'];
        $data->country = $input['country'];
        $data->linkedin_address = $input['linkedin_address'];
        $data->lead_name = $input['job_title'];*/

    
        $data->save();
        
        return redirect('leads')->with('success', 'Lead Updated Successfully.');
    }


    public function destroy($id)
    {
        //
    }

    public function delete($id)
    {
        $lead = Lead::findOrFail($id);
        $lead->delete();
        return redirect('leads')->with('success', 'Lead Deleted Successfully.');
    }

    public function searchLead(SearchLeadRequest $request)
    {

        if($request->has('source_id') && !empty($request->input('source_id'))) {
            $data = Lead::where('source_id', $request->source_id)->with('source')->get()->toArray();
             $source_ids = $request->source_id;
        } else {
            $data = Lead::where(['user_id'=>auth()->user()->id])->with('source')->get()->toArray();
             $source_ids = "";
        }

         $sources = Source::where(['user_id'=>auth()->user()->id])->select('id','source_name')->get()->toArray();

         return view('leads.list')->with(['data'=>$data,'sources'=>$sources,'source_ids'=>$source_ids]);
         //return redirect('leads')->with(['data'=>$data,'sources'=>$sources]);
    }


    public function view()
    {

          // dd('ddd');
        $data = Lead::where(['user_id'=>auth()->user()->id])->whereNotIn('status', [1])->with('source')->get()->toArray();
        $employees = User::where(['user_id'=>auth()->user()->id, 'is_admin'=>'1'])->get()->toArray();
        $employee_ids = "";
        return view('leads.view')->with(['employees'=>$employees,'data'=>$data,'employee_ids'=>$employee_ids]);
    }


    public function views()
    {
 
          if(request()->get('employee_id')){
              $employee_id =  $_GET['employee_id']; 
          }else{
              $employee_id =  "";
          }
          
          
          if(request()->get('date_from')){
              $date_from =  $_GET['date_from']; 
          }else{
              $date_from =  "";
          }
          
          
          if(request()->get('date_to')){
              $date_to =  $_GET['date_to']; 
          }else{
              $date_to =  "";
          }
          
        
        $data = new Lead;
    
        if(request()->get('employee_id')){

            $data = $data->where('asign_to', '=', $_GET['employee_id']);

        }
     
        if(request()->get('date_from') && request()->get('date_to')){
          
            $from = date($_GET['date_from']);
            $to = date($_GET['date_to']);

            $data = $data->whereBetween('created_at', [$from, $to]);
         
        }
   
        //$data = $data->where(['user_id'=>auth()->user()->id])->whereNotNull('asign_to')->with('source')->get()->toArray();
        
        $data =  $data->whereHas('users', function ($query) {
                    $query->where(['user_id'=>auth()->user()->id]);
          })->with('source')->get()->toArray();
      
        $employees = User::where(['user_id'=>auth()->user()->id, 'is_admin'=>'1'])->get()->toArray();
        
         return view('leads.view')->with(['employees'=>$employees,'data'=>$data,'employee_id'=>$employee_id,'date_from'=>$date_from,'date_to'=>$date_to]);
    }


    public function assign()
    {   
        $data = Lead::with('source')->where(['user_id'=>auth()->user()->id,'status'=>'1','asign_to'=>NULL])->get()->toArray();
        $employees = User::where(['user_id'=>auth()->user()->id,'is_admin'=>'1'])->get()->toArray();
        return view('leads.assign')->with(['employees'=>$employees,'data'=>$data]);
    }

    public function assigns(Request $request)
    {

        /*if($request->has('employee_id') && !empty($request->input('employee_id'))) {
            $data = Lead::where('asign_to', $request->employee_id)->with('source')->get()->toArray();
        } else {
            $data = Lead::with('source')->get()->toArray();
        }*/
        $data = Lead::with('source')->where(['status'=>'1'])->get()->toArray();
        $employees = User::where(['is_admin'=>'1'])->get()->toArray();

         return view('leads.assign')->with(['employees'=>$employees,'data'=>$data]);
    }

    public function closed()
    {
         $data = Lead::with('source')->where(['asign_to'=>auth()->user()->id])->with('feedback')->where(['status'=>'3'])->get()->toArray();
         //dd($data);
         return view('leads.closed')->with(['data'=>$data]);
    }


    public function failed()
    {
         $data = Lead::with('source')->where(['asign_to'=>auth()->user()->id])->with('feedback')->where(['status'=>'2'])->get()->toArray();
         return view('leads.failed')->with(['data'=>$data]);
    }


    public function changeStatus(Request $request)
    {

        /*$validator = Validator::make($request->all(), [
            'status' => 'required',
        ]);


        if ($validator->passes()) {

            $data = array(
                'status'=>$request->status
            );
            
             //Lead::where('id', $request->lead_id)->update(['status'=>$request->status]);
            return response()->json(['success'=>'Updated Successfully.']);
        }
        return response()->json(['error'=>$validator->errors()->all()]);

        */
         $notesCount =  Note::where(['lead_id'=>$request->lead_id])->count();
        if($notesCount == 0){

           return response()->json(['error'=>'Please add a note first.']);

        }else{

            
             Lead::where('id', $request->lead_id)->update(['status'=>$request->status]);
            return response()->json(['success'=>'Updated Successfully.']);

        }
            
    }

    public function assignLeadsEmployee(AssignLeadRequest $request)
    {

            $data = array(
                'employee_id'=>$request->employee_id,
                'lead_id'=>$request->lead_id
            );
            
            foreach($request->lead_id as $leadid) {
            Lead::where('id', $leadid)->update(['asign_to'=>$request->employee_id]);
            }

            return redirect('leads/assign')->with('success', 'Leads Assigned Successfully.');
            
    }

    public function getLeads(Request $request)
    {  
        $data =array();
        if ($request->has('employee_id')) {
            $data = Lead::where('asign_to', $request->employee_id)->get()->toArray();
        }
        return response()->json($data);
    }

 

}
