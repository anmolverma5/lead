<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Exports\BulkExport;
use App\Imports\BulkImport;
use Maatwebsite\Excel\Facades\Excel;

use App\Http\Requests\ImportRequest;

class ImportExportController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
    * 
    */
    public function importLeads()
    {
       return view('importexport');
    }
    public function import(ImportRequest $request) 
    {
        Excel::import(new BulkImport,request()->file('file'));
           
        return back()->with('success', 'Leads Imported Successfully.');;
    }
}

