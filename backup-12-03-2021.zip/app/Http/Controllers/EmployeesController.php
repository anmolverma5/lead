<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Hash;

use App\Models\User;
use App\Models\Lead;

use App\Http\Requests\EmployeeRequest;
use App\Http\Requests\ManagerEmployeeRequest;

use App\Http\Requests\EditEmployeeRequest;
use App\Http\Requests\EditManagerEmployeeRequest;

use Validator;

class EmployeesController extends Controller
{
    
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {

         $data = User::where(['is_admin'=>'1','user_id'=>auth()->user()->id])->get()->toArray();
          return view('employees.list')->with(['data'=>$data]);
        
    }

    public function create()
    {
            $employeeCount = User::where(['user_id'=>auth()->user()->id,'is_admin'=>'1'])->count();
            //print_R(auth()->user()->is_admin);die;
            if(auth()->user()->is_admin != NULL){
                if($employeeCount >= 2){
            
                    return redirect('employees')->with('error', 'Please contact with admin to add more employees.');
                }else{
    
                    return view('employees.add');
                }
            }else{
                return view('employees.add');
            }
    }


    public function store(EmployeeRequest $request)
    {

        $password = rand(10000000,99999999);

         $data = array(
            'user_id'=>auth()->user()->id,
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            'name'=>$request->first_name.' '.$request->last_name,
            'phone_no'=>$request->phone_no,
            'email'=>$request->email,
            'password'=>Hash::make($password),
            'orignal_password'=>$password,
            'address'=>$request->address,
            'is_admin'=>'1',
        );

        User::create($data);
        
        return redirect('employees')->with('success', 'Employee Added Successfully.');
        
    }
    
    
    public function addManagerEmployee()
    {
        $managers = User::where(['is_admin'=>'2'])->select('id','name')->get()->toArray();
        return view('employees.addManagerEmployee')->with(['managers'=>$managers]);
    }
    
    
    public function storeManagerEmployee(ManagerEmployeeRequest $request)
    {

        $password = rand(10000000,99999999);

         $data = array(
            'user_id'=>$request->manager_id,
            'first_name'=>$request->first_name,
            'last_name'=>$request->last_name,
            'name'=>$request->first_name.' '.$request->last_name,
            'phone_no'=>$request->phone_no,
            'email'=>$request->email,
            'password'=>Hash::make($password),
            'orignal_password'=>$password,
            'address'=>$request->address,
            'is_admin'=>'1',
        );

        User::create($data);
        
        return redirect()->route('employees.show', ['id' => $request->manager_id])->with('success', 'Employee Added Successfully.');
        
    }
    
    
    public function editManagerEmployee($id)
    {
        $managers = User::where(['is_admin'=>'2'])->select('id','name')->get()->toArray();
        $data = User::where(['id'=>$id])->first();
        return view('employees.editManagerEmployee')->with(['data'=>$data,'managers'=>$managers]);
    }


    public function updateManagerEmployee(Request $request, $id)
    {
        
         $validator = Validator::make(
            $request->all(), [
                'first_name' => 'required|min:3|max:20',
                'last_name' => 'required|min:3|max:20',
               //'email' => 'required|email|unique:users',
               'email' => 'required|email|unique:users,email,'.$id,
                'phone_no' => 'required|min:10|numeric|unique:users,phone_no,'.$id,
                'address' => 'required|min:3|max:30',
            ],
            $messages = [
                'required' => 'The :attribute field is required.',
            ]
        );
        
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        
        $input = $request->all(); 

        $data = User::find($id);
        
        $data->user_id = $input['manager_id'];
        $data->first_name = $input['first_name'];
        $data->last_name = $input['last_name'];
        $data->name = $input['first_name'].' '.$input['last_name'];
        $data->phone_no = $input['phone_no'];
        $data->email = $input['email'];
        $data->address = $input['address'];
    
        $data->save();

        //return redirect('employees')->with('success', 'Employee Updated Successfully.');
         return redirect()->route('employees.show', ['id' => $request->manager_id])->with('success', 'Employee Added Successfully.');
    }
    
    
    public function deleteManagerEmployee($id)
    {
        $employee = User::findOrFail($id);
        $employee->delete();
        return redirect()->back()->with('success', 'Employee Deleted Successfully.');
    }


    public function show($id)
    {
          $manager = User::where(['id'=>$id])->select('name')->first();
          $data = User::where(['is_admin'=>'1','user_id'=>$id])->get()->toArray();
          return view('employees.listManagerEmployee')->with(['data'=>$data,'manager'=>$manager]);
    }

    public function edit($id)
    {
       
        $data = User::where(['id'=>$id])->first();
        return view('employees.edit')->with(['data'=>$data]);
    }


    public function update(Request $request, $id)
    {
        //dd($request->email);
        $validator = Validator::make(
            $request->all(), [
                'first_name' => 'required|min:3|max:20',
                'last_name' => 'required|min:3|max:20',
               //'email' => 'required|email|unique:users',
               'email' => 'required|email|unique:users,email,'.$id,
                'phone_no' => 'required|min:10|numeric|unique:users,phone_no,'.$id,
                'address' => 'required|min:3|max:30',
            ],
            $messages = [
                'required' => 'The :attribute field is required.',
            ]
        );
        
        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator)->withInput();
        }
        
        $input = $request->all(); 

        $data = User::find($id);
        
        $data->first_name = $input['first_name'];
        $data->last_name = $input['last_name'];
        $data->name = $input['first_name'].' '.$input['last_name'];
        $data->phone_no = $input['phone_no'];
        $data->email = $input['email'];
        $data->address = $input['address'];
    
        $data->save();

        return redirect('employees')->with('success', 'Employee Updated Successfully.');
    }


    public function destroy($id)
    {
        //
    }
    
    public function statusUpdate($id)
    {
       
        $manager = User::findOrFail($id);
        //dd($manager->first_name);
        //$manager->first_name = "DEMO";
        
        if($manager->is_active == 1){
            $manager->is_active = 2;
        }
        else
        {
            $manager->is_active = 1;
        }
        
        $manager->save();
        
        
        return redirect('employees')->with('success', 'Status Changed');
        
    }

    public function delete($id)
    {
        //dd('ddd');
        //Lead::where(['asign_to'=>$id,'status'=>'1'])->update(['asign_to'=>NULL]);
        $employee = User::findOrFail($id);
        $employee->delete();
        return redirect('employees')->with('success', 'Employee Deleted Successfully.');
    }
}
